sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
		"sap/ui/core/routing/History"
], function(Controller, MessageToast, JSONModel, History) {
	"use strict";

	var ViewController = Controller.extend("Split.controller.Detail", {
		
		onInit: function(){
			
		}
	
	});
		return ViewController;
});